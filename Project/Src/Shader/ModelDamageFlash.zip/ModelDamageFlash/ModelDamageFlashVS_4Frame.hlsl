#include "../Common/Vertex/VertexInputType.hlsli"
#define VERTEX_INPUT DX_MV1_VERTEX_TYPE_4FRAME
#include "../Default/DefaultVSBody.hlsli"
