#pragma once

#include "../CameraEventBase.h"

class WaitCameraEvent : public CameraEventBase
{
public:
	WaitCameraEvent(float frame);

	~WaitCameraEvent()override = default;

	void Update(CameraBase& camera) override;

    bool IsEnd() const override { return currentFrame >= maxFrame; }

private:
	// �҂��t���[����
	const float maxFrame;
	// �X�V�t���[����
	float currentFrame;
};