#pragma once

#include "../Common/ActorBase/ActorBase.h"

class TutorialStage : public ActorBase
{
public:

	TutorialStage();

	~TutorialStage()override = default;

	// ���[�h
	void Load(void)override;

private:

};