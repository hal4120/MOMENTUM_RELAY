#include "TutorialStage.h"

#include "../Common/Collider/MeshCollider.h"

TutorialStage::TutorialStage() :
	ActorBase()
{
}

void TutorialStage::Load(void)
{
	// ���f��
	trans.LoadModel("TutorialStage/Base/Base");

	// �X�P�[��
	trans.scale = 15;

	// �R���C�_�[
	AddCollider(new MeshCollider(COLLIDER_TAG::Stage));
}
