#include "TestBoxObject.h"

#include "Common/Collider/BoxCollider.h"
#include "Common/PhysicsBody/PhysicsBody.h"

int TestBoxObject::modelHandleOriginal = -1;

TestBoxObject::TestBoxObject(const Vector3& size, const Vector3& pos, TestMode mode) :
    ActorBase(), testMode(mode), boxSize(size)
{
    trans.pos = pos;

    // ����Body�̗L���ƓƗ����āA����Collider�Ƃ��ēo�^����B
    SetColliderMobility(COLLIDER_MOBILITY::Movable);
    SetContactResponseEnabled(true);
    SetGravityFlg(mode != TestMode::SpinInAir);
}

void TestBoxObject::Load(void)
{
    if (modelHandleOriginal == -1) { modelHandleOriginal = MV1LoadModel("Data/Model/Blocks/Block_Crate.mv1"); }
    //trans.LoadModel("Blocks/Block_Crate");
    trans.model = modelHandleOriginal;

    trans.scale = boxSize / Vector3(200);

    // BoxCollider��ActorBase���Ǘ��E�������B
    AddCollider(new BoxCollider(COLLIDER_TAG::DebugObject, boxSize));

    // SpinInAir�ł��p���x���؂�PhysicsBody���K�v�B
    CreatePhysicsBody();
    PhysicsBody* body = GetPhysicsBody();
    if (body == nullptr) { return; }

    body->SetMode(PhysicsBody::MotionMode::Dynamic);
    body->SetMass(0.2f);
    body->SetRotationEnabled(true);
    body->SetShapeInertiaBox(boxSize);
    body->SetRestitution(0.05f);
    body->SetFriction(0.6f);
    body->SetAngularDragPerFrame(0.005f);
    body->SetHorizontalDragPerFrame(0.03f);
    body->SetGravityEnabled(testMode != TestMode::SpinInAir);

    if (testMode == TestMode::SpinInAir) {
        // �O������̗͂Ȃ��ŉ�]���������؂���B
        body->SetAngularVelocity(Vector3(0.0f, 0.025f, 0.0f));
    }
}

void TestBoxObject::SubRelease(void)
{
    if (modelHandleOriginal != -1) {
        MV1DeleteModel(modelHandleOriginal);
        modelHandleOriginal = -1;
    }
}