#include "ModelDamageFlashShader.h"

#include <algorithm>
#include <cmath>

#include "../../../pch.h"

#include "../../../Manager/Shader/ShaderResourceManager.h"

#include "../../../Manager/TimeScale/TimeScale.h"

ModelDamageFlashShader::ModelDamageFlashShader(int duration, int count, float power, SHADER_VERTEX_TYPE type) :
    ShaderBase(),
    vertexType(type),
    durationFrames((std::max)(1, duration)),
    flashes((std::max)(1, count)),
    elapsedFrames(0),
    strength(std::clamp(power, 0.0f, 1.0f)),
    constantBufferHandle(-1)
{
}

void ModelDamageFlashShader::Init(void)
{
    // �V�F�[�_�[�n���h���Ǘ��N���X���擾
    ShaderResourceManager& manager = ShaderResourceManager::GetIns();

    // �g�p���钸�_�V�F�[�_�[�𒸓_�^�C�v���Q�Ƃ��Č��肷��
    VERTEX_SHADER_TYPE useVertexShaderType = VERTEX_SHADER_TYPE::ModelDamageFlash1Frame;
    useVertexShaderType = (VERTEX_SHADER_TYPE)((int)useVertexShaderType + (int)vertexType);

    // ���_�V�F�[�_�[�̐���
    manager.CreateVertexShader(useVertexShaderType);
    // �s�N�Z���V�F�[�_�[�̐���
    manager.CreatePixelShader(PIXEL_SHADER_TYPE::ModelDamageFlash);

    // �g�p���钸�_�V�F�[�_�[��ێ�
    vertexShaderHandle = manager.GetVertexShader(useVertexShaderType);

    // �g�p����s�N�Z���V�F�[�_�[��ێ�
    pixelShaderHandle = manager.GetPixelShader(PIXEL_SHADER_TYPE::ModelDamageFlash);

    // �萔�o�b�t�@�̐���
    constantBufferHandle = CreateShaderConstantBuffer(sizeof(float) * 4);

}

void ModelDamageFlashShader::Update(void)
{
    if (IsEnd()) return;

    elapsedFrames += TimeScale::Get();
}

void ModelDamageFlashShader::Apply(void)
{
    float intensity = 0.0f;
    if (!IsEnd())
    {
        const float progress = static_cast<float>(elapsedFrames) / durationFrames;
        // 0 -> 1 -> 0 �� flashes ��J��Ԃ�
        const float wave = std::abs(std::sin(progress * flashes * DX_PI_F));
        // �㔼�Ɍ����ď�������
        intensity = strength * wave * (1.0f - 0.35f * progress);
    }

    float* data = static_cast<float*>(GetBufferShaderConstantBuffer(constantBufferHandle));
    if (data)
    {
        data[0] = intensity;
        data[1] = data[2] = data[3] = 0.0f;
        UpdateShaderConstantBuffer(constantBufferHandle);
        SetShaderConstantBuffer(constantBufferHandle, DX_SHADERTYPE_PIXEL, FLASH_REGISTER);
    }
    ShaderBase::Apply();
}

void ModelDamageFlashShader::ResetApply(void)
{
    ShaderBase::ResetApply();
    SetShaderConstantBuffer(-1, DX_SHADERTYPE_PIXEL, FLASH_REGISTER);
}

bool ModelDamageFlashShader::IsEnd(void) const
{
    return elapsedFrames >= durationFrames;
}

void ModelDamageFlashShader::Release(void)
{
    if (constantBufferHandle != -1) {
        DeleteShaderConstantBuffer(constantBufferHandle);

        constantBufferHandle = -1;
    }
    if (vertexShaderHandle != -1) vertexShaderHandle = -1;
    if (pixelShaderHandle != -1) pixelShaderHandle = -1;
    ShaderBase::Release();
}
