#include "ColliderBase.h"

#include <cassert>

#include "../ActorBase/ActorBase.h"

CollisionResult::CollisionResult(void) :
	point(),
	normal(),
	penetration(0.0f)
{
}


ColliderBase::ColliderBase(COLLIDER_TAG type, const Vector3& pos, const Quaternion& rotation) :
	owner(nullptr),

	pos(pos),
	rotation(rotation.Normalized()),

	judgeFlg(true),

	tag(type),
	shape(COLLIDER_SHAPE::None),

	OnCollision(nullptr),
	OnPushed(nullptr)
{
}


void ColliderBase::SetActorPtr(ActorBase* ptr)
{
	owner = ptr;
}

void ColliderBase::SetOnCollisionFunc(std::function<void(COLLIDER_TAG, const ColliderBase&, const CollisionResult&)> OnCollisionFunc)
{
	OnCollision = std::move(OnCollisionFunc);
}


void ColliderBase::SetOnPushedFunc(std::function<void(COLLIDER_TAG, const ColliderBase&, const Vector3&)> OnPushedFunc)
{
	OnPushed = std::move(OnPushedFunc);
}


ActorBase* ColliderBase::GetActor(void) const
{
	assert(owner != nullptr);

	return owner;
}

Vector3 ColliderBase::GetPos(void) const
{
	assert(owner != nullptr);

	/*
		���΍��Wpos��Transform�{�̂̉�]�݂̂��󂯂�B

		Collider���g��rotation�́A
		Collider�̌`�����]�����邽�߂̂��̂Ȃ̂�
		���΍��W�ɂ͓K�p���Ȃ��B
	*/
	return owner->GetTrans().pos + owner->GetTrans().VTrans(pos);
}


Vector3 ColliderBase::GetPrevPos(void) const
{
	assert(owner != nullptr);

	return owner->GetTrans().prevPos + owner->GetTrans().VTrans(pos);
}


Quaternion ColliderBase::GetRotation(void) const
{
	assert(owner != nullptr);

	/*
		Transform�{�̂̉�]
			��
		Collider�ŗL�̑��Ή�]

		�̏��Ԃō�������B

		���i�K�ł͊���ActionBase�̍s��K���
		�m���Ɉێ����邽�߁ADxLib�̍s��ō������Ă���
		Quaternion�֕ϊ�����B
	*/
	return Quaternion::FromMatrix(GetRotationMat());
}


MATRIX ColliderBase::GetRotationMat(void) const
{
	assert(owner != nullptr);

	return MMult(owner->GetTrans().RotationMat(), rotation.ToMatrix());
}


Vector3 ColliderBase::VTrans(const Vector3& v) const
{
	if (v == 0.0f) { return Vector3(); }

	return Vector3(VTransform(v.ToVECTOR(), GetRotationMat()));
}

bool ColliderBase::GetJudgeFlg(void) const
{
	return judgeFlg;
}

COLLIDER_TAG ColliderBase::GetTag(void) const
{
	return tag;
}


COLLIDER_SHAPE ColliderBase::GetShape(void) const
{
	return shape;
}


void ColliderBase::CallOnCollision(COLLIDER_TAG ownTag, const ColliderBase& other, const CollisionResult& result)
{
	if (!OnCollision) { return; }

	OnCollision(ownTag, other, result);
}


void ColliderBase::CallOnPushed(COLLIDER_TAG ownTag, const ColliderBase& other, const Vector3& pushVec)
{
	if (!OnPushed) { return; }

	OnPushed(ownTag, other, pushVec);
}


void ColliderBase::SetTransformPos(const Vector3& pos)
{
	assert(owner != nullptr);

	owner->SetPos(pos);
}


void ColliderBase::SetTransformPosAdd(const Vector3& vec)
{
	assert(owner != nullptr);

	owner->SetPos(owner->GetTrans().pos + vec);
}


void ColliderBase::SetJudgeFlg(bool flg)
{
	judgeFlg = flg;
}


void ColliderBase::SetShape(COLLIDER_SHAPE s)
{
	shape = s;
}