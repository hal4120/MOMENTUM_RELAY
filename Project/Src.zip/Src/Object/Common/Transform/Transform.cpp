#include "Transform.h"

#include "../../../Utility/Utility.h"

Vector3 Transform::Velocity(void) const
{
	return pos - prevPos;
}

MATRIX Transform::RotationMat(void) const
{
	return rotation.ToMatrix();
}

Quaternion Transform::FinalRotation(void) const
{
	// ���[�J���␳ �� �{�̉�]

	const MATRIX localMat = localRotation.ToMatrix();
	const MATRIX rotationMat = rotation.ToMatrix();

	const MATRIX finalMat = MMult(localMat, rotationMat);

	return Quaternion::FromMatrix(finalMat);
}

MATRIX Transform::FinalRotationMat(void) const
{
	return MMult(localRotation.ToMatrix(), rotation.ToMatrix());
}

Vector3 Transform::VTrans(const Vector3& v) const
{
	if (v == 0.0f) { return Vector3(); }

	return Vector3(VTransform(v.ToVECTOR(), RotationMat()));
}

Vector3 Transform::VTrans(const VECTOR& v) const
{
	return VTrans(Vector3(v));
}

#pragma region ��]�ݒ�

void Transform::SetRotation(const Quaternion& rotation)
{
	this->rotation = rotation.Normalized();
}

void Transform::SetAngle(const Vector3& angle)
{
	rotation = Quaternion::FromEulerXZY(angle);
}

void Transform::SetAngleDeg(const Vector3& deg)
{
	SetAngle(Deg2Rad(deg));
}

void Transform::SetAngleXDeg(float deg)
{
	SetAngle(Vector3::Xonly(Deg2Rad(deg)));
}

void Transform::SetAngleYDeg(float deg)
{
	SetAngle(Vector3::Yonly(Deg2Rad(deg)));
}

void Transform::SetAngleZDeg(float deg)
{
	SetAngle(Vector3::Zonly(Deg2Rad(deg)));
}

void Transform::AddAngle(const Vector3& angle)
{
	const Quaternion addRotation = Quaternion::FromEulerXZY(angle);

	// ��]�̍����������m���Ɋ����̍s��K��֍��킹��B
	const MATRIX result = MMult(rotation.ToMatrix(), addRotation.ToMatrix());

	rotation = Quaternion::FromMatrix(result);
}

void Transform::AddAngleDeg(const Vector3& deg)
{
	AddAngle(Deg2Rad(deg));
}

void Transform::AddAngleXDeg(float deg)
{
	AddAngle(Vector3::Xonly(Deg2Rad(deg)));
}

void Transform::AddAngleYDeg(float deg)
{
	AddAngle(Vector3::Yonly(Deg2Rad(deg)));
}

void Transform::AddAngleZDeg(float deg)
{
	AddAngle(Vector3::Zonly(Deg2Rad(deg)));
}

void Transform::SetLocalRotation(const Quaternion& rotation)
{
	localRotation = rotation.Normalized();
}

void Transform::SetLocalAngle(const Vector3& angle)
{
	localRotation = Quaternion::FromEulerXZY(angle);
}

void Transform::SetLocalAngleDeg(const Vector3& deg)
{
	SetLocalAngle(Deg2Rad(deg));
}

#pragma endregion

void Transform::LoadModel(std::string path)
{
	model = MV1LoadModel(("Data/Model/" + path + ".mv1").c_str());
}

void Transform::Duplicate(int model)
{
	this->model = MV1DuplicateModel(model);
}

MATRIX Transform::GetWorldMatrix(void) const
{
	// �ŏI��]
	const MATRIX rotationMat = FinalRotationMat();

	// �`����W
	const Vector3 drawPos =
		pos + Vector3(
			VTransform(centerDiff.ToVECTOR(), rotationMat)
		);

	// �X�P�[��
	MATRIX modelMat = MGetTranslate(animationOffset.ToVECTOR());
	modelMat = MMult(modelMat, MGetScale(scale.ToVECTOR()));

	// ��]
	modelMat = MMult(modelMat, rotationMat);

	// ���W
	modelMat = MMult(
		modelMat,
		MGetTranslate(drawPos.ToVECTOR())
	);

	return modelMat;
}

void Transform::Attach(void)
{
	if (model == -1) { return; }

	MV1SetMatrix(model, GetWorldMatrix());
}

void Transform::Draw(void)
{
	// ���I�I�u�W�F�N�g�͖��t���[��Attach���Ȃ���
	if (dynamicFlg) { Attach(); }

	// �`��
	MV1DrawModel(model);
}

void Transform::Release(void)
{
	if (model == -1) { return; }

	MV1DeleteModel(model);
}