#pragma once

#include "../ActorBase/ActorBase.h"

#include "../../../Manager/Input/InputManager.h"
#include "../../../Manager/Camera/CurrentCamera.h"

#include "../Collider/ColliderBase.h"

class DebugObjectBase : public ActorBase
{
public:
	DebugObjectBase(
		const Vector3& pos,

		bool dynamicFlg,
		bool isGravity,
		bool pushFlg,

		bool isOperator
	) :
		ActorBase(),
		isOperator(isOperator)
	{
		trans.pos = pos;
		SetColliderMobility(dynamicFlg ? COLLIDER_MOBILITY::Movable : COLLIDER_MOBILITY::Static);
		SetGravityFlg(isGravity);
		SetContactResponseEnabled(pushFlg);
	}
	DebugObjectBase(
		const std::string& parameterPath,

		const Vector3& pos,

		bool dynamicFlg,
		bool isGravity,
		bool pushFlg,

		bool isOperator
	) :
		ActorBase(parameterPath),
		isOperator(isOperator)
	{
		trans.pos = pos;
		SetColliderMobility(dynamicFlg ? COLLIDER_MOBILITY::Movable : COLLIDER_MOBILITY::Static);
		SetGravityFlg(isGravity);
		SetContactResponseEnabled(pushFlg);
	}
	~DebugObjectBase()override = default;

	void OnCollision(COLLIDER_TAG ownTag, const ColliderBase& other, const CollisionResult& result)override {
		if (other.GetTag() == COLLIDER_TAG::CameraLine) { SetDrawType(ACTOR_DRAW_TYPE::Alpha); }
	}

private:
	// ����\���ǂ���
	bool isOperator;

	void SubInit(void)override {
		// �ړ�������
		ACCEL_RATE = 3.0f;
		// �ړ�������
		DECEL_RATE = 3.0f;
		// �ő�ړ����x
		ACCEL_MAX = 15.0f;
	}

	void SubUpdate(void)override {
		SetDrawType(ACTOR_DRAW_TYPE::Default);

		if (!isOperator) { return; }

		// �ړ�����
		Vector3 vec = {};

		// ����
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectFront).now) { vec.z++; }
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectBack).now) { vec.z--; }
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectRight).now) { vec.x++; }
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectLeft).now) { vec.x--; }
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectUp).now) { vec.y++; }
		if (Input::GetIns().GetInfo(KEY_TYPE::DebugObjectDown).now) { vec.y--; }

		// �J�����̊p�x�ɍ��킹�Ĉړ���������]������
		vec.TransMatOwn(MGetRotY(CurrentCamera::Get().GetRotation().GetYaw()));

		// �ړ�
		MoveAccel(vec);
	}
};