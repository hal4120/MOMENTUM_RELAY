#include "UnderWaterPostEffect.h"

#include "../../../../pch.h"

#include "../../../../Manager/Shader/ShaderResourceManager.h"

UnderWaterPostEffect::UnderWaterPostEffect() :
	PostEffectBase(),

	constBufferData{},
	constBufferHandle(-1)
{
	constBufferData.time = 0.0f;
	constBufferData.intensity = 1.0f;
	constBufferData.distortionStrength = 0.003f;
	constBufferData.distortionSpeed = 2.0f;
}

void UnderWaterPostEffect::Init(void)
{
	// �s�N�Z���V�F�[�_�[���擾
	ShaderResourceManager::GetIns().CreatePixelShader(PIXEL_SHADER_TYPE::UnderWater);
	pixelShaderHandle = ShaderResourceManager::GetIns().GetPixelShader(PIXEL_SHADER_TYPE::UnderWater);

	// �萔�o�b�t�@���쐬
	constBufferHandle = CreateShaderConstantBuffer(sizeof(ConstBuffer));
}

void UnderWaterPostEffect::Update(void)
{
	// ���Ԃ�i�߂�
	constBufferData.time += 1.0f / 60.0f;
}

void UnderWaterPostEffect::Release(void)
{
	if (constBufferHandle >= 0) {
		DeleteShaderConstantBuffer(constBufferHandle);
		constBufferHandle = -1;
	}
}

void UnderWaterPostEffect::ApplyParameter(void)
{
	if (constBufferHandle < 0) { return; }

	// �萔�o�b�t�@�̏������ݐ���擾
	auto* buffer =
		static_cast<ConstBuffer*>(
			GetBufferShaderConstantBuffer(
				constBufferHandle
			)
			);

	if (buffer == nullptr) { return; }

	// CPU���̃f�[�^����������
	*buffer = constBufferData;

	// GPU�֔��f
	UpdateShaderConstantBuffer(constBufferHandle);

	// PixelShader��b0�֐ݒ�
	SetShaderConstantBuffer(constBufferHandle, DX_SHADERTYPE_PIXEL, 0);
}

void UnderWaterPostEffect::ResetParameter(void)
{
	// PixelShader��b0������
	SetShaderConstantBuffer(-1, DX_SHADERTYPE_PIXEL, 0);
}
