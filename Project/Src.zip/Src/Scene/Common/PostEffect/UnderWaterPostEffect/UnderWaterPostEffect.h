#pragma once

#include "../PostEffectBase.h"

class UnderWaterPostEffect : public PostEffectBase
{
public:
	UnderWaterPostEffect();
	~UnderWaterPostEffect() override = default;

	void Init(void) override;
	void Update(void) override;
	void Release(void) override;

protected:

	void ApplyParameter(void) override;
	void ResetParameter(void) override;

private:

	struct ConstBuffer
	{
        // �o�ߎ���
        float time;

        // �����G�t�F�N�g�S�̂̋���
        float intensity;

        // �h��̋���
        float distortionStrength;

        // �h��̑��x
        float distortionSpeed;
	};

	ConstBuffer constBufferData;

    int constBufferHandle;
};