// �_�̃p�����[�^
cbuffer CloudParam : register(b4)
{
    float time;
    float cloudScale;
    float cloudSpeed;
    float cloudCoverage;

    float cloudOpacity;
    float3 padding;
};

struct SkyBoxInput
{
    float4 svPos : SV_POSITION;
    float3 direction : TEXCOORD0;
};

// �^������
float Hash(float2 p)
{
    return frac(
        sin(dot(p, float2(127.1f, 311.7f))) *
        43758.5453f
    );
}

// 2D Value Noise
float Noise(float2 p)
{
    float2 i = floor(p);
    float2 f = frac(p);

    // ���炩�ȕ��
    f = f * f * (3.0f - 2.0f * f);

    float a = Hash(i);
    float b = Hash(i + float2(1.0f, 0.0f));
    float c = Hash(i + float2(0.0f, 1.0f));
    float d = Hash(i + float2(1.0f, 1.0f));

    return lerp(
        lerp(a, b, f.x),
        lerp(c, d, f.x),
        f.y
    );
}

// 3�w�̃m�C�Y������
float FBM(float2 p)
{
    float value = 0.0f;
    float amplitude = 0.5f;

    for (int i = 0; i < 3; ++i)
    {
        value += Noise(p) * amplitude;

        p *= 2.0f;
        amplitude *= 0.5f;
    }

    return value / 0.875f;
}

float4 main(SkyBoxInput input) : SV_TARGET
{
    float3 dir = normalize(input.direction);

    float height = dir.y;

    // ==============================
    // ��̃O���f�[�V����
    // ==============================

    float3 zenithColor = float3(
        0.08f, 0.35f, 0.85f
    );

    float3 horizonColor = float3(
        0.65f, 0.85f, 1.0f
    );

    float3 bottomColor = float3(
        0.85f, 0.90f, 0.95f
    );

    float3 skyColor;

    if (height >= 0.0f)
    {
        float t = pow(saturate(height), 0.65f);

        skyColor = lerp(
            horizonColor,
            zenithColor,
            t
        );
    }
    else
    {
        skyColor = lerp(
            horizonColor,
            bottomColor,
            saturate(-height)
        );
    }

    // ==============================
    // �_�̐���
    // ==============================

    // �n�����t�߂�UV���ɒ[�ɑ傫���Ȃ�Ȃ��悤�ɂ���
    float safeHeight = max(height, 0.08f);

    // ���̉��z���ʂ֓��e
    float2 cloudUV = dir.xz / safeHeight;

    cloudUV *= cloudScale;

    // ���Ԍo�߂ɂ��_�̈ړ�
    cloudUV += float2(
        time * cloudSpeed,
        time * cloudSpeed * 0.35f
    );

    // �m�C�Y����
    float noiseValue = FBM(cloudUV);

    // �_�̗֊s
    float cloud = smoothstep(
        cloudCoverage - 0.12f,
        cloudCoverage + 0.12f,
        noiseValue
    );

    // �n�����t�߂ł͉_������
    float horizonFade = smoothstep(
        0.03f,
        0.25f,
        height
    );

    cloud *= horizonFade;

    // �_�̓����x
    cloud *= cloudOpacity;

    // ==============================
    // �_�̐F
    // ==============================

    float3 cloudShadow = float3(
        0.72f, 0.80f, 0.88f
    );

    float3 cloudLight = float3(
        1.0f, 1.0f, 1.0f
    );

    // �m�C�Y�ɉ����ĉ_�ɔZ�W������
    float3 cloudColor = lerp(
        cloudShadow,
        cloudLight,
        saturate(noiseValue * 1.5f)
    );

    // ��Ɖ_������
    float3 finalColor = lerp(
        skyColor,
        cloudColor,
        saturate(cloud)
    );

    return float4(finalColor, 1.0f);
}