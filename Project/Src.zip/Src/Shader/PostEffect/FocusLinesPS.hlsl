#include "PostEffectHeader.hlsli"

cbuffer FocusLinesParam : register(b0)
{
    float time;
    float intensity;
    float speed;
    float lineCount;
};


// ------------------------------------------------------------
// �^������
// ------------------------------------------------------------
float Random(float seed)
{
    return frac(
        sin(seed * 12.9898f) *
        43758.5453f
    );
}


// ------------------------------------------------------------
// �W����
// ------------------------------------------------------------
float4 main(PS_INPUT input) : SV_TARGET
{
    uint textureWidth;
    uint textureHeight;

    sceneTexture.GetDimensions(
        textureWidth,
        textureHeight
    );

    float2 screenSize =
        float2(
            textureWidth,
            textureHeight
        );


    // ���摜
    float2 uv = input.uv;

    float4 color =
        GetSceneColor(uv);


    // --------------------------------------------------------
    // ��ʒ��������_��
    // --------------------------------------------------------

    float2 p = uv - 0.5f;

    float aspect =
        screenSize.x /
        screenSize.y;

    p.x *= aspect;


    // ��������̋���
    float dist = length(p);


    // �p�x
    const float PI = 3.14159265f;

    float angle =
        atan2(
            p.y,
            p.x
        );

    float angle01 =
        angle /
        (2.0f * PI) +
        0.5f;


    // --------------------------------------------------------
    // ���Ԃɂ���āu���̔z�u�p�^�[���v���̂��̂�ύX
    // --------------------------------------------------------

    float anim =
        time * speed;

    float currentFrame =
        floor(anim);

    float nextFrame =
        currentFrame + 1.0f;

    float frameBlend =
        smoothstep(
            0.0f,
            1.0f,
            frac(anim)
        );


    // --------------------------------------------------------
    // �p�x��lineCount�̗̈�֕���
    // --------------------------------------------------------

    float count =
        max(
            lineCount,
            1.0f
        );

    float lineValue =
        angle01 * count;

    float lineIndex =
        floor(lineValue);

    float localAngle =
        frac(lineValue);


    // --------------------------------------------------------
    // ���݃t���[���̃����_���l
    // --------------------------------------------------------

    float seedA =
        lineIndex +
        currentFrame * 137.0f;

    float angleRandomA =
        Random(seedA + 11.0f);

    float lengthRandomA =
        Random(seedA + 29.0f);

    float widthRandomA =
        Random(seedA + 47.0f);

    float brightnessRandomA =
        Random(seedA + 71.0f);

    float enableRandomA =
        Random(seedA + 89.0f);


    // --------------------------------------------------------
    // ���t���[���̃����_���l
    // --------------------------------------------------------

    float seedB =
        lineIndex +
        nextFrame * 137.0f;

    float angleRandomB =
        Random(seedB + 11.0f);

    float lengthRandomB =
        Random(seedB + 29.0f);

    float widthRandomB =
        Random(seedB + 47.0f);

    float brightnessRandomB =
        Random(seedB + 71.0f);

    float enableRandomB =
        Random(seedB + 89.0f);


    // --------------------------------------------------------
    // �����_���l�����ԕ��
    // --------------------------------------------------------

    float angleRandom =
        lerp(
            angleRandomA,
            angleRandomB,
            frameBlend
        );

    float lengthRandom =
        lerp(
            lengthRandomA,
            lengthRandomB,
            frameBlend
        );

    float widthRandom =
        lerp(
            widthRandomA,
            widthRandomB,
            frameBlend
        );

    float brightnessRandom =
        lerp(
            brightnessRandomA,
            brightnessRandomB,
            frameBlend
        );

    float enableRandom =
        lerp(
            enableRandomA,
            enableRandomB,
            frameBlend
        );


    // --------------------------------------------------------
    // ���̊p�x�ʒu
    //
    // �������ȑO�Ƃ̑傫�ȈႢ�B
    // ���̒��S�ʒu���̂��̂������_���Ɉړ�������B
    // --------------------------------------------------------

    float lineCenter =
        angleRandom;

    float lineDistance =
        abs(
            localAngle -
            lineCenter
        );

    // 0�`1�̋��E���ׂ��ꍇ
    lineDistance =
        min(
            lineDistance,
            1.0f - lineDistance
        );


    // --------------------------------------------------------
    // ���̑���
    // --------------------------------------------------------

    float lineWidth =
        lerp(
            0.015f,
            0.10f,
            widthRandom
        );

    float angleMask =
        1.0f -
        smoothstep(
            lineWidth * 0.3f,
            lineWidth,
            lineDistance
        );


    // --------------------------------------------------------
    // ���̒���
    //
    // �O�����璆�������֐L�т�B
    // --------------------------------------------------------

    float innerRadius =
    lerp(
        0.40f,
        0.58f,
        lengthRandom
    );

    float outerRadius =
        lerp(
            0.65f,
            1.10f,
            Random(seedA + 103.0f)
        );


    // �������E
    float innerMask =
        smoothstep(
            innerRadius,
            innerRadius + 0.04f,
            dist
        );


    // �O�����E
    float outerMask =
        1.0f -
        smoothstep(
            outerRadius,
            outerRadius + 0.10f,
            dist
        );


    float radialMask =
        innerMask *
        outerMask;


    // --------------------------------------------------------
    // �O���قǑ�������
    //
    // ���ˏ�̎O�p�`���ۂ��W�����ɂȂ�
    // --------------------------------------------------------

    float radialWidth =
        saturate(
            (
                dist -
                innerRadius
            ) * 3.0f
        );

    float wideAngleMask =
        1.0f -
        smoothstep(
            lineWidth *
            lerp(
                0.25f,
                1.8f,
                radialWidth
            ),

            lineWidth *
            lerp(
                0.5f,
                2.4f,
                radialWidth
            ),

            lineDistance
        );


    // --------------------------------------------------------
    // �ꕔ�̐�������
    //
    // �S�����ɋϓ��ɕ���ł��銴�����Ȃ���
    // --------------------------------------------------------

    float appearMask =
        smoothstep(
            0.30f,
            0.50f,
            enableRandom
        );


    // --------------------------------------------------------
    // ���邳
    // --------------------------------------------------------

    float brightness =
        lerp(
            0.35f,
            1.0f,
            brightnessRandom
        );


    // �א� + ����������������
    float lineMask =
        max(
            angleMask * 0.4f,
            wideAngleMask
        );


    // --------------------------------------------------------
    // �ŏI�I�ȏW����
    // --------------------------------------------------------

    float focusLine =
        lineMask *
        radialMask *
        appearMask *
        brightness *
        intensity;


    // �����W���������Z
    color.rgb += focusLine.xxx;

    return color;
}