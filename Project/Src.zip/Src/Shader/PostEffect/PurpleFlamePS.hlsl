#include "PostEffectHeader.hlsli"

// ============================================================
// �萔�o�b�t�@
// ============================================================

cbuffer PurpleFlameParam : register(b0)
{
    float time;
    float intensity;
    float flameHeight;
    float flameSpeed;
};


// ============================================================
// �^������
// ============================================================

float Hash(float2 p)
{
    return frac(
        sin(dot(p, float2(127.1f, 311.7f))) *
        43758.5453f
    );
}


// ============================================================
// 2D Value Noise
// ============================================================

float Noise(float2 p)
{
    float2 i = floor(p);
    float2 f = frac(p);

    f = f * f * (3.0f - 2.0f * f);

    float a = Hash(i);
    float b = Hash(i + float2(1.0f, 0.0f));
    float c = Hash(i + float2(0.0f, 1.0f));
    float d = Hash(i + float2(1.0f, 1.0f));

    return lerp(
        lerp(a, b, f.x),
        lerp(c, d, f.x),
        f.y
    );
}


// ============================================================
// Fractal Brownian Motion
// �����̃m�C�Y���d�˂ĉ��炵�����G�Ȍ`������
// ============================================================

float FBM(float2 p)
{
    float value = 0.0f;
    float amplitude = 0.5f;

    [unroll]
    for (int i = 0; i < 4; ++i)
    {
        value += Noise(p) * amplitude;

        p *= 2.0f;
        amplitude *= 0.5f;
    }

    return value;
}


// ============================================================
// �s�N�Z���V�F�[�_�[
// ============================================================

float4 main(PS_INPUT input) : SV_TARGET
{
    float2 uv = input.uv;

    // ���̃Q�[�����
    float4 sceneColor = GetSceneColor(uv);

    // --------------------------------------------------------
    // ��ʉ��[�����_�Ƃ�������
    // --------------------------------------------------------

    // ��ʉ��[ = 0
    // ��ʏ�[ = 1
    float height = 1.0f - uv.y;

    float safeHeight = max(flameHeight, 0.001f);

    // ���̍����𐳋K��
    float normalizedHeight = height / safeHeight;

    // --------------------------------------------------------
    // ���ԂŃm�C�Y��������֗���
    // --------------------------------------------------------

    float t = time * flameSpeed;

    float2 noiseUV = float2(
        uv.x * 7.0f,
        normalizedHeight * 3.0f - t
    );

    // �傫�ȉ��̗h�炬
    float largeNoise = FBM(noiseUV);

    // �ׂ������̗h�炬
    float detailNoise = FBM(
        noiseUV * 2.8f +
        float2(13.7f, -t * 0.7f)
    );

    // --------------------------------------------------------
    // ���̗֊s
    // --------------------------------------------------------

    // �m�C�Y�ɂ���ĉ��̐�[���㉺������
    float flameTop =
        0.55f +
        largeNoise * 0.55f +
        detailNoise * 0.20f;

    // ������flameTop�𒴂���Ə�����
    float flameMask =
        1.0f -
        smoothstep(
            flameTop - 0.15f,
            flameTop + 0.10f,
            normalizedHeight
        );

    // --------------------------------------------------------
    // ���̓����͗l
    // --------------------------------------------------------

    float innerNoise = FBM(
        float2(
            uv.x * 12.0f,
            normalizedHeight * 5.0f - t * 1.5f
        )
    );

    // ���̋؂����
    float flameDetail =
        smoothstep(
            0.25f,
            0.85f,
            innerNoise
        );

    // ��ɍs���قǔ�������
    float heightFade =
        1.0f -
        smoothstep(
            0.1f,
            1.15f,
            normalizedHeight
        );

    // --------------------------------------------------------
    // ���̋��x
    // --------------------------------------------------------

    float flame =
        flameMask *
        heightFade *
        (0.45f + flameDetail * 0.55f);

    flame *= saturate(intensity);

    // --------------------------------------------------------
    // ���F�O���f�[�V����
    // --------------------------------------------------------

    // �O���F�Â���
    float3 outerColor = float3(
        0.18f,
        0.01f,
        0.32f
    );

    // ���ԁF��
    float3 middleColor = float3(
        0.55f,
        0.05f,
        0.85f
    );

    // �����F���邢�s���N��
    float3 innerColor = float3(
        1.0f,
        0.35f,
        0.95f
    );

    float3 flameColor = lerp(
        outerColor,
        middleColor,
        saturate(flameDetail * 1.5f)
    );

    flameColor = lerp(
        flameColor,
        innerColor,
        pow(saturate(flameDetail), 3.0f)
    );

    // --------------------------------------------------------
    // ����
    // --------------------------------------------------------

    float glow = flame * flame;

    flameColor += innerColor * glow * 0.35f;

    // --------------------------------------------------------
    // ����ʂƍ���
    // --------------------------------------------------------

    // ���Z�������̉��\��
    float3 result =
        sceneColor.rgb +
        flameColor * flame;

    return float4(
        saturate(result),
        sceneColor.a
    );
}